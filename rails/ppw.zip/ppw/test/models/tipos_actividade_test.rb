require "test_helper"

class TiposActividadeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
