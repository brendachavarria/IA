require "test_helper"

class ActividadesAlumnoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
