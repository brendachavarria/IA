require "test_helper"

class DireccioneTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
