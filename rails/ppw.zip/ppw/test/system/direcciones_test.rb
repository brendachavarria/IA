require "application_system_test_case"

class DireccionesTest < ApplicationSystemTestCase
  setup do
    @direccione = direcciones(:one)
  end

  test "visiting the index" do
    visit direcciones_url
    assert_selector "h1", text: "Direcciones"
  end

  test "should create direccione" do
    visit direcciones_url
    click_on "New direccione"

    fill_in "Calle", with: @direccione.calle
    fill_in "Colonia", with: @direccione.colonia
    fill_in "Cp", with: @direccione.cp
    fill_in "Estado", with: @direccione.estado
    fill_in "Municipio", with: @direccione.municipio
    fill_in "Num exterior", with: @direccione.num_exterior
    fill_in "Num interior", with: @direccione.num_interior
    fill_in "Referencia", with: @direccione.referencia
    click_on "Create Direccione"

    assert_text "Direccione was successfully created"
    click_on "Back"
  end

  test "should update Direccione" do
    visit direccione_url(@direccione)
    click_on "Edit this direccione", match: :first

    fill_in "Calle", with: @direccione.calle
    fill_in "Colonia", with: @direccione.colonia
    fill_in "Cp", with: @direccione.cp
    fill_in "Estado", with: @direccione.estado
    fill_in "Municipio", with: @direccione.municipio
    fill_in "Num exterior", with: @direccione.num_exterior
    fill_in "Num interior", with: @direccione.num_interior
    fill_in "Referencia", with: @direccione.referencia
    click_on "Update Direccione"

    assert_text "Direccione was successfully updated"
    click_on "Back"
  end

  test "should destroy Direccione" do
    visit direccione_url(@direccione)
    click_on "Destroy this direccione", match: :first

    assert_text "Direccione was successfully destroyed"
  end
end
