require "application_system_test_case"

class TiposActividadesTest < ApplicationSystemTestCase
  setup do
    @tipos_actividade = tipos_actividades(:one)
  end

  test "visiting the index" do
    visit tipos_actividades_url
    assert_selector "h1", text: "Tipos actividades"
  end

  test "should create tipos actividade" do
    visit tipos_actividades_url
    click_on "New tipos actividade"

    fill_in "Tipo", with: @tipos_actividade.tipo
    click_on "Create Tipos actividade"

    assert_text "Tipos actividade was successfully created"
    click_on "Back"
  end

  test "should update Tipos actividade" do
    visit tipos_actividade_url(@tipos_actividade)
    click_on "Edit this tipos actividade", match: :first

    fill_in "Tipo", with: @tipos_actividade.tipo
    click_on "Update Tipos actividade"

    assert_text "Tipos actividade was successfully updated"
    click_on "Back"
  end

  test "should destroy Tipos actividade" do
    visit tipos_actividade_url(@tipos_actividade)
    click_on "Destroy this tipos actividade", match: :first

    assert_text "Tipos actividade was successfully destroyed"
  end
end
