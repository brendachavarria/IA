require "application_system_test_case"

class ActividadesTest < ApplicationSystemTestCase
  setup do
    @actividade = actividades(:one)
  end

  test "visiting the index" do
    visit actividades_url
    assert_selector "h1", text: "Actividades"
  end

  test "should create actividade" do
    visit actividades_url
    click_on "New actividade"

    fill_in "Cupo", with: @actividade.cupo
    fill_in "Descripcion", with: @actividade.descripcion
    fill_in "Docente", with: @actividade.docente
    fill_in "Grupo", with: @actividade.grupo_id
    fill_in "Horario", with: @actividade.horario
    fill_in "Inscritos", with: @actividade.inscritos
    fill_in "Nombre", with: @actividade.nombre
    fill_in "Tipo", with: @actividade.tipo
    click_on "Create Actividade"

    assert_text "Actividade was successfully created"
    click_on "Back"
  end

  test "should update Actividade" do
    visit actividade_url(@actividade)
    click_on "Edit this actividade", match: :first

    fill_in "Cupo", with: @actividade.cupo
    fill_in "Descripcion", with: @actividade.descripcion
    fill_in "Docente", with: @actividade.docente
    fill_in "Grupo", with: @actividade.grupo_id
    fill_in "Horario", with: @actividade.horario
    fill_in "Inscritos", with: @actividade.inscritos
    fill_in "Nombre", with: @actividade.nombre
    fill_in "Tipo", with: @actividade.tipo
    click_on "Update Actividade"

    assert_text "Actividade was successfully updated"
    click_on "Back"
  end

  test "should destroy Actividade" do
    visit actividade_url(@actividade)
    click_on "Destroy this actividade", match: :first

    assert_text "Actividade was successfully destroyed"
  end
end
