require "application_system_test_case"

class CarrerasTest < ApplicationSystemTestCase
  setup do
    @carrera = carreras(:one)
  end

  test "visiting the index" do
    visit carreras_url
    assert_selector "h1", text: "Carreras"
  end

  test "should create carrera" do
    visit carreras_url
    click_on "Nueva carrera"

    fill_in "Nombre", with: @carrera.nombre
    fill_in "Siglas", with: @carrera.siglas
    click_on "Crear una nueva Carrera"

    assert_text "La carrera fue creada correctamente"
    click_on "Regresar"
  end

  test "should update Carrera" do
    visit carrera_url(@carrera)
    click_on "Editar esta carrera", match: :first

    fill_in "Nombre", with: @carrera.nombre
    fill_in "Siglas", with: @carrera.siglas
    click_on "Actualizar esta Carrera"

    assert_text "Carrera fue actualizada correctamente"
    click_on "Regresar"
  end

  test "should destroy Carrera" do
    visit carrera_url(@carrera)
    click_on "Eliminar esta carrera", match: :first

    assert_text "La carrera fue eliminada correctamente"
  end
end
