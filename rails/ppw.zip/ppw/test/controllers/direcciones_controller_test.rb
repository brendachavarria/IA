require "test_helper"

class DireccionesControllerTest < ActionDispatch::IntegrationTest
  setup do
    @direccione = direcciones(:one)
  end

  test "should get index" do
    get direcciones_url
    assert_response :success
  end

  test "should get new" do
    get new_direccione_url
    assert_response :success
  end

  test "should create direccione" do
    assert_difference("Direccione.count") do
      post direcciones_url, params: { direccione: { calle: @direccione.calle, colonia: @direccione.colonia, cp: @direccione.cp, estado: @direccione.estado, municipio: @direccione.municipio, num_exterior: @direccione.num_exterior, num_interior: @direccione.num_interior, referencia: @direccione.referencia } }
    end

    assert_redirected_to direccione_url(Direccione.last)
  end

  test "should show direccione" do
    get direccione_url(@direccione)
    assert_response :success
  end

  test "should get edit" do
    get edit_direccione_url(@direccione)
    assert_response :success
  end

  test "should update direccione" do
    patch direccione_url(@direccione), params: { direccione: { calle: @direccione.calle, colonia: @direccione.colonia, cp: @direccione.cp, estado: @direccione.estado, municipio: @direccione.municipio, num_exterior: @direccione.num_exterior, num_interior: @direccione.num_interior, referencia: @direccione.referencia } }
    assert_redirected_to direccione_url(@direccione)
  end

  test "should destroy direccione" do
    assert_difference("Direccione.count", -1) do
      delete direccione_url(@direccione)
    end

    assert_redirected_to direcciones_url
  end
end
