require "test_helper"

class TiposActividadesControllerTest < ActionDispatch::IntegrationTest
  setup do
    @tipos_actividade = tipos_actividades(:one)
  end

  test "should get index" do
    get tipos_actividades_url
    assert_response :success
  end

  test "should get new" do
    get new_tipos_actividade_url
    assert_response :success
  end

  test "should create tipos_actividade" do
    assert_difference("TiposActividade.count") do
      post tipos_actividades_url, params: { tipos_actividade: { tipo: @tipos_actividade.tipo } }
    end

    assert_redirected_to tipos_actividade_url(TiposActividade.last)
  end

  test "should show tipos_actividade" do
    get tipos_actividade_url(@tipos_actividade)
    assert_response :success
  end

  test "should get edit" do
    get edit_tipos_actividade_url(@tipos_actividade)
    assert_response :success
  end

  test "should update tipos_actividade" do
    patch tipos_actividade_url(@tipos_actividade), params: { tipos_actividade: { tipo: @tipos_actividade.tipo } }
    assert_redirected_to tipos_actividade_url(@tipos_actividade)
  end

  test "should destroy tipos_actividade" do
    assert_difference("TiposActividade.count", -1) do
      delete tipos_actividade_url(@tipos_actividade)
    end

    assert_redirected_to tipos_actividades_url
  end
end
