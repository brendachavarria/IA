Rails.application.routes.draw do
  resources :tipos_actividades
  resources :direcciones_tipos
  resources :direcciones
  devise_for :users
  root to: 'home#index'
  resources :carreras
  resources :actividades_alumnos
  get "students", to: "students#show"
  get "teachers", to: "teachers#show"
  get "teachers/:id/edit", to: "teachers#edit", as: :teacher_edit
  get "students/:id/edit", to: "students#edit", as: :student_edit
  resources :teachers, only: [:show, :edit, :update]
  resources :students, only: [:show, :edit, :update]
  get "actividades", to: "actividades#index", as: :actividade
  get "actividades/new_student/:id", to: "actividades#new_student", as: :inscribe
  post "actividades/new_student/:id", to: "actividades#inscribirse", as: :create_student
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html
  # Defines the root path route ("/")
  # root "articles#index"
end
