# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# This file is the source Rails uses to define your schema when running `bin/rails
# db:schema:load`. When creating a new database, `bin/rails db:schema:load` tends to
# be faster and is potentially less error prone than running all of your
# migrations from scratch. Old migrations may fail to apply correctly if those
# migrations use external dependencies or application code.
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema[7.0].define(version: 2022_05_18_212514) do
  create_table "actividades", force: :cascade do |t|
    t.string "nombre"
    t.string "tipo"
    t.integer "grupo_id"
    t.string "docente"
    t.string "horario"
    t.string "descripcion"
    t.integer "cupo"
    t.integer "inscritos"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "actividades_alumnos", force: :cascade do |t|
    t.integer "grupo_id"
    t.integer "no_control_student"
    t.float "calificacion"
    t.string "observaciones"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.integer "actividad_id"
    t.integer "teacher_id", null: false
    t.integer "student_id", null: false
    t.index ["student_id"], name: "index_actividades_alumnos_on_student_id"
    t.index ["teacher_id"], name: "index_actividades_alumnos_on_teacher_id"
  end

  create_table "carreras", force: :cascade do |t|
    t.string "nombre"
    t.string "siglas"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "direcciones", force: :cascade do |t|
    t.string "calle"
    t.integer "num_exterior"
    t.integer "num_interior"
    t.string "colonia"
    t.string "municipio"
    t.string "estado"
    t.integer "cp"
    t.string "referencia"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "direcciones_tipos", force: :cascade do |t|
    t.string "tipo"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "students", force: :cascade do |t|
    t.integer "no_control"
    t.integer "semeste"
    t.string "nombre"
    t.string "apellido_p"
    t.string "apellido_m"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.integer "user_id", null: false
    t.integer "carrera_id", default: 1, null: false
    t.index ["carrera_id"], name: "index_students_on_carrera_id"
    t.index ["user_id"], name: "index_students_on_user_id"
  end

  create_table "teachers", force: :cascade do |t|
    t.string "nombre"
    t.string "apellido_p"
    t.string "apellido_m"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.integer "user_id", null: false
    t.index ["user_id"], name: "index_teachers_on_user_id"
  end

  create_table "tipos_actividades", force: :cascade do |t|
    t.string "tipo"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

# Could not dump table "users" because of following StandardError
#   Unknown type 'string' for column 'role'

  add_foreign_key "actividades_alumnos", "actividades", column: "actividad_id"
  add_foreign_key "actividades_alumnos", "students"
  add_foreign_key "actividades_alumnos", "teachers"
  add_foreign_key "students", "carreras"
  add_foreign_key "students", "users"
  add_foreign_key "teachers", "users", primary_key: "id"
end
