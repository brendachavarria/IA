class AddTeacherIdToActividadesAlumnos < ActiveRecord::Migration[7.0]
  def change
    add_reference :actividades_alumnos, :teacher, null: false, foreign_key: true
  end
end
