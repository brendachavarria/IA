class CreateTeachers < ActiveRecord::Migration[7.0]
  def change
    create_table :teachers do |t|
      t.string :nombre
      t.string :apellido_p
      t.string :apellido_m

      t.timestamps
    end
  end
end
