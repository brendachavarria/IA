class AddTeacherIdToActividades < ActiveRecord::Migration[7.0]
  def change
    add_reference :actividades, :teacher, null: false, foreign_key: true
  end
end
