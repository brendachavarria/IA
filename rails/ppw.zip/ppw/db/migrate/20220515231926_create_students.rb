class CreateStudents < ActiveRecord::Migration[7.0]
  def change
    create_table :students do |t|
      t.integer :no_control
      t.integer :semeste
      t.string :nombre
      t.string :apellido_p
      t.string :apellido_m

      t.timestamps
    end
  end
end
