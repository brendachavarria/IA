class CreateDirecciones < ActiveRecord::Migration[7.0]
  def change
    create_table :direcciones do |t|
      t.string :calle
      t.integer :num_exterior
      t.integer :num_interior
      t.string :colonia
      t.string :municipio
      t.string :estado
      t.integer :cp
      t.string :referencia

      t.timestamps
    end
  end
end
