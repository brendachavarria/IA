class CreateActividades < ActiveRecord::Migration[7.0]
  def change
    create_table :actividades do |t|
      t.string :nombre
      t.string :tipo
      t.integer :grupo_id
      t.string :docente
      t.string :horario
      t.string :descripcion
      t.integer :cupo
      t.integer :inscritos

      t.timestamps
    end
  end
end
