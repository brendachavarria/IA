class TutankamonMailer < ApplicationMailer
  def alum_registro
    @user = params[:user]
    @activity = params[:activity]
    attachments['tec.jpg'] = File.read('app/assets/images/tec.jpg')
    mail(to: @user.email, subject: 'Bienvenido a la actividad')
  end
  def carre_registro
    @user = params[:user]
    @carrera = params[:carrera]
    attachments['tec.jpg'] = File.read('app/assets/images/tec.jpg')
    mail(to: @user.email, subject: 'Se creo la actividad con exito')
  end
end