class ApplicationMailer < ActionMailer::Base
  default from: "lizbethrami2021@gmail.com"
  layout "mailer"
end
