class ApplicationController < ActionController::Base
  before_action :authenticate_user!
  layout :layout_by_recource

  private

  def layout_by_recource
    if devise_controller?
      "devise"
    else
      "application"
    end
  end

end
