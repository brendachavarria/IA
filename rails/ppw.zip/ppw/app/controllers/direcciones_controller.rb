class DireccionesController < ApplicationController
  before_action :set_direccione, only: %i[ show edit update destroy ]

  # GET /direcciones or /direcciones.json
  def index
    @direcciones = Direccione.all
  end

  # GET /direcciones/1 or /direcciones/1.json
  def show
  end

  # GET /direcciones/new
  def new
    @direccione = Direccione.new
  end

  # GET /direcciones/1/edit
  def edit
  end

  # POST /direcciones or /direcciones.json
  def create
    @direccione = Direccione.new(direccione_params)

    respond_to do |format|
      if @direccione.save
        format.html { redirect_to direccione_url(@direccione), notice: "Direccion se creó correctamente." }
        format.json { render :show, status: :created, location: @direccione }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @direccione.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /direcciones/1 or /direcciones/1.json
  def update
    respond_to do |format|
      if @direccione.update(direccione_params)
        format.html { redirect_to direccione_url(@direccione), notice: "Direccion se actualizó correctamente." }
        format.json { render :show, status: :ok, location: @direccione }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @direccione.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /direcciones/1 or /direcciones/1.json
  def destroy
    @direccione.destroy

    respond_to do |format|
      format.html { redirect_to direcciones_url, notice: "Direccion fue destruido con éxito." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_direccione
      @direccione = Direccione.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def direccione_params
      params.require(:direccione).permit(:calle, :num_exterior, :num_interior, :colonia, :municipio, :estado, :cp, :referencia)
    end
end
