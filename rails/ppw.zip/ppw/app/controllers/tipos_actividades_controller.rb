class TiposActividadesController < ApplicationController
  before_action :set_tipos_actividade, only: %i[ show edit update destroy ]

  # GET /tipos_actividades or /tipos_actividades.json
  def index
    @tipos_actividades = TiposActividade.all
  end

  # GET /tipos_actividades/1 or /tipos_actividades/1.json
  def show
  end

  # GET /tipos_actividades/new
  def new
    @tipos_actividade = TiposActividade.new
  end

  # GET /tipos_actividades/1/edit
  def edit
  end

  # POST /tipos_actividades or /tipos_actividades.json
  def create
    @tipos_actividade = TiposActividade.new(tipos_actividade_params)

    respond_to do |format|
      if @tipos_actividade.save
        format.html { redirect_to tipos_actividade_url(@tipos_actividade), notice: "Tipos actividade was successfully created." }
        format.json { render :show, status: :created, location: @tipos_actividade }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @tipos_actividade.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /tipos_actividades/1 or /tipos_actividades/1.json
  def update
    respond_to do |format|
      if @tipos_actividade.update(tipos_actividade_params)
        format.html { redirect_to tipos_actividade_url(@tipos_actividade), notice: "Tipos actividade was successfully updated." }
        format.json { render :show, status: :ok, location: @tipos_actividade }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @tipos_actividade.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /tipos_actividades/1 or /tipos_actividades/1.json
  def destroy
    @tipos_actividade.destroy

    respond_to do |format|
      format.html { redirect_to tipos_actividades_url, notice: "Tipos actividade was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_tipos_actividade
      @tipos_actividade = TiposActividade.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def tipos_actividade_params
      params.require(:tipos_actividade).permit(:tipo)
    end
end
