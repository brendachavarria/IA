class ActividadesController < ApplicationController
  before_action :set_actividade, only: %i[ show edit update destroy ]

  # GET /actividades or /actividades.json
  def index
    @actividades = Actividade.all
  end

  # GET /actividades/1 or /actividades/1.json
  def show
  end

  # GET /actividades/new
  def new
    @actividade = Actividade.new
  end

  # GET /actividades/1/edit
  def edit
  end

  def inscribirse
    @actividade = Actividade.find(params[:id])

    @set_inscribed_s = @actividade.actividade_group

    #@set_inscribed_s = ActivityGroup.find_by activity_id: @activity

    @actividade = Actividade.find(params[:id])
    @create_student = ActividadesAlumno.create(grupo_id: @actividade.grupo_id,
                                               actividad_id: @actividade.id,
                                               teacher_id: @actividade.teacher.id,
                                               student_id: @actividade.student.id,
                                               student_id: @actividade.student.no_control)
  end

  def new_student
    @actividade = Actividade.find(params[:id])
    @create_student = ActividadesAlumno.new
  end

  # POST /actividades or /actividades.json
  def create
    @actividade = Actividade.new(actividade_params)

    respond_to do |format|
      if @actividade.save
        format.html { redirect_to actividade_url(@actividade), notice: "La actividades fue creada correctamente." }
        format.json { render :show, status: :created, location: @actividade }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @actividade.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /actividades/1 or /actividades/1.json
  def update
    respond_to do |format|
      if @actividade.update(actividade_params)
        format.html { redirect_to actividade_url(@actividade), notice: "La actividad fue actualizada." }
        format.json { render :show, status: :ok, location: @actividade }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @actividade.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /actividades/1 or /actividades/1.json
  def destroy
    @actividade.destroy

    respond_to do |format|
      format.html { redirect_to actividades_url, notice: "La actividad fue destruida." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_actividade
      @actividade = Actividade.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def actividade_params
      params.require(:actividade).permit(:nombre, :tipo, :grupo_id, :docente, :horario, :descripcion, :cupo, :inscritos)
    end

end
