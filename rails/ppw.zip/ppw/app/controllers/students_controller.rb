class StudentsController < ApplicationController
  before_action :set_student
  #before_action :set_student_role

  def show
    a = current_user.student.carrera_id
    @career = Carrera.find_by id: a
  end

  def edit
    @careers = Carrera.all
  end

  def update
    respond_to do |format|
      if @student.update(student_params)
        format.html  { redirect_to(@student,
                                   :notice => 'El perfil estudiante ha sido actualizado.') }
      else
        format.html  { render :action => "edit" }
        format.json  { render :json => @student.errors,
                              :status => :unprocessable_entity }
      end
    end
  end

  private
  def set_student
    @student = (current_user.student ||= Student.create)
  end

  private
  def set_student_role
    @role = (current_user.role ||= Role.create)
  end

  def student_params
    params.require(:student).permit(:nombre, :apellido_p, :apellido_m, :no_control, :semeste, :carrera_id)
  end
end