class TeachersController < ApplicationController
  before_action :set_teacher

  def show
  end

  def edit
  end

  def update
    respond_to do |format|
      if @teacher.update(teacher_params)
        format.html  { redirect_to(@teacher,
                                   :notice => 'El perfil docente ha sido actualizado.') }
      else
        format.html  { render :action => "edit" }
        format.json  { render :json => @teacher.errors,
                              :status => :unprocessable_entity }
      end
    end
  end

  private
  def set_teacher
    @teacher = (current_user.teacher ||= Teacher.create)
  end

  def teacher_params
    params.require(:teacher).permit(:nombre, :apellido_p, :apellido_m)
  end
end