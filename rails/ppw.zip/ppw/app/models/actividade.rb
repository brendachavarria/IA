class Actividade < ApplicationRecord
  belongs_to :Tipo, class_name:"TiposActividade", foreign_key: "tipo"
  belongs_to :teacher, class_name:"Teacher", foreign_key: "id"
  belongs_to :student, class_name:"Student", foreign_key: "id"
end
