class ActividadesAlumno < ApplicationRecord
  validates :calificacion, presence: true

  belongs_to :student
  belongs_to :teacher
  belongs_to :actividade

end
