class Direccione < ApplicationRecord
  validates :calle, presence: true
  validates :colonia, format: { with: /\A[a-zA-Z]+\z/,
                                    message: "solo puedes escribir numeros" }
  validates :estado, inclusion: { in: %w(small),
                                message: "%{value} no es valido para municipio" }
  validates :cp, length: { is: 5 }
end

