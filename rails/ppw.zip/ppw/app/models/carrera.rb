class Carrera < ApplicationRecord
  has_many :students
  validates :nombre, presence: true
  validates :siglas, presence: true
  validates :siglas, format: { with: /\A[a-zA-Z]+\z/,
                               message: "solo se pueden ingresar letras" }
end
