class Student < ApplicationRecord
  belongs_to :user
  has_one :student, dependent: :destroy
  belongs_to :carrera
  has_many :actividades, class_name:"Actividade", foreign_key: "id"

end
