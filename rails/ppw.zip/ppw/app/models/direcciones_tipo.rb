class DireccionesTipo < ApplicationRecord
end
