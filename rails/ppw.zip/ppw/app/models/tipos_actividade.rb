class TiposActividade < ApplicationRecord
end
