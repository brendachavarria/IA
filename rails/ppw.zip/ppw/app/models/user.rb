class User < ApplicationRecord
  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable, :trackable and :omniauthable
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :validatable

  has_one :teacher, dependent: :destroy
  has_one :student, dependent: :destroy

  after_create :set_profile

  def set_profile
    self.profile = Profile.create()
  end

  def set_teacher
    self.teacher = Teacher.create()
  end

  def set_student
    self.student = Student.create()
  end
end
