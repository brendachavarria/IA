class Teacher < ApplicationRecord
  belongs_to :user
  has_one :teacher, dependent: :destroy
  has_many :actividades, class_name:"Actividade", foreign_key: "id"

end
